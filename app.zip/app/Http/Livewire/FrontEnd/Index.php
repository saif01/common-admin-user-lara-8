<?php

namespace App\Http\Livewire\FrontEnd;

use Livewire\Component;

use App\Models\Admin\Setting\HomeBackground;
use App\Models\Admin\Setting\HomeSlider;

class Index extends Component
{
    public $bgImage, $sliderText;

    public function mount(){

        $data  = HomeBackground::where('status', '1')->first();
        $data2 = HomeSlider::where('status', '1')->get();

        if($data){

            $imgName = $data->image;
            //dd($imgName);
            $this->bgImage =asset('images/background').'/'.$imgName;

        }else{
            $this->bgImage = asset('all-assets/front-end/img/hero-bg.jpg');
        }

        if($data2){
            $this->sliderText =  $data2;
        }

        
    }

    public function render()
    {
        return view('livewire.front-end.index');
    }
}
