<?php

namespace App\Http\Livewire\FrontEnd\Busniess;

use Livewire\Component;

use App\Models\Admin\Business\BusinessAll;

class All extends Component
{
    public $name;

    public function mount($name){
        $this->name = $name;
    } 

    
    public function render()
    {
        $allData = BusinessAll::where('name', $this->name)->first();

        return view('livewire.front-end.busniess.all', compact('allData'));
    }
}
