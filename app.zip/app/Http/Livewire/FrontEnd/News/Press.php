<?php

namespace App\Http\Livewire\FrontEnd\News;

use Livewire\Component;

use App\Models\Admin\News\NewsPress;
use Livewire\WithPagination;
use App\Http\Livewire\Common\dataTbl\TblComponants;

class Press extends Component
{
    use WithPagination, TblComponants;

    protected $paginationTheme = 'bootstrap';
   
    public function render()
    {
        $allData= NewsPress::where('status', '1')
        ->search( trim(preg_replace('/\s+/' ,' ', $this->search)) )
        ->orderBy('date', 'desc')
        ->paginate(5);

        return view('livewire.front-end.news.press', compact('allData'));
    }
}
