<?php

namespace App\Http\Livewire\FrontEnd\News;

use Livewire\Component;

use App\Models\Admin\News\NewsGallery;
use Livewire\WithPagination;
use App\Http\Livewire\Common\dataTbl\TblComponants;

class Gallery extends Component
{
    use WithPagination, TblComponants;

    protected $paginationTheme = 'bootstrap';
   
    public function render()
    {
        $allData= NewsGallery::where('status', '1')
            ->orderBy('id', 'desc')
            ->paginate(9);

        return view('livewire.front-end.news.gallery', compact('allData'));
    }
}
