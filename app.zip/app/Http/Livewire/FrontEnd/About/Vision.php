<?php

namespace App\Http\Livewire\FrontEnd\About;

use Livewire\Component;

use App\Models\Admin\About\AboutVision;

class Vision extends Component
{
    public function render()
    {
        $allData= AboutVision::where('status', '1')->orderBy('id')->get();

        return view('livewire.front-end.about.vision' , compact('allData'));
    }
}
