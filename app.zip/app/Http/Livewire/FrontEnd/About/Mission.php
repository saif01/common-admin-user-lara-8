<?php

namespace App\Http\Livewire\FrontEnd\About;

use Livewire\Component;

use App\Models\Admin\About\AboutMission;

class Mission extends Component
{
    public function render()
    {
        $allData= AboutMission::where('status', '1')->orderBy('id')->get();

        return view('livewire.front-end.about.mission', compact('allData'));
    }
}
