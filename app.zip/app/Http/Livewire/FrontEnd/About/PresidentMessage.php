<?php

namespace App\Http\Livewire\FrontEnd\About;

use Livewire\Component;

use App\Models\Admin\About\AboutPresidentMessage;

class PresidentMessage extends Component
{
    public function render()
    {
        $allData= AboutPresidentMessage::where('status', '1')->orderBy('id')->first();

        return view('livewire.front-end.about.president-message', compact('allData'));
    }
}
