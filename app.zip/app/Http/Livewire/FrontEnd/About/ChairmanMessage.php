<?php

namespace App\Http\Livewire\FrontEnd\About;

use Livewire\Component;

use App\Models\Admin\About\AboutChairmanMessage;

class ChairmanMessage extends Component
{
    public function render()
    {
        $allData= AboutChairmanMessage::where('status', '1')->orderBy('id')->first();

        return view('livewire.front-end.about.chairman-message', compact('allData'));
    }
}
