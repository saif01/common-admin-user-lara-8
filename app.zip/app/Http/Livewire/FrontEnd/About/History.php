<?php

namespace App\Http\Livewire\FrontEnd\About;

use Livewire\Component;

use App\Models\Admin\About\AboutHistory;

class History extends Component
{
    public function render()
    {
        $allData= AboutHistory::where('status', '1')->orderBy('id')->get();

        return view('livewire.front-end.about.history', compact('allData'));
    }
}
