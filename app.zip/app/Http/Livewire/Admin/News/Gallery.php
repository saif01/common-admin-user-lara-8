<?php

namespace App\Http\Livewire\Admin\News;

use Livewire\Component;

use Livewire\WithPagination;
use Auth;
use App\Models\Admin\News\NewsGallery;

use Livewire\WithFileUploads;
use Image;

use App\Http\Livewire\Common\fileUpload\ImgUpFunctions;
use App\Http\Livewire\Common\dataTbl\Conformation;
use App\Http\Livewire\Common\dataTbl\TblComponants;
use App\Http\Livewire\Common\Modal\ModalOpenClose;

class Gallery extends Component
{

    use WithPagination, ImgUpFunctions, Conformation, TblComponants, ModalOpenClose;

    protected $paginationTheme = 'bootstrap';
 
    public $assetUrl, $selectAll = false, $selected = [], $images = [], $bulkDeleteConform = false;



    public function mount(){
        $this->assetUrl = asset('images/gallery/small').'/';
    }


    // Select all data by checkbox
    public function updatedSelectAll( $value ){

        if( $value ){

            //checked selectall btn then all data will checked
            $this->selected = NewsGallery::pluck('id');
          
        }else{
            //Unchecked all
            //$this->selectAll = false;
            $this->selected = [];
            
        }
    }

    // bulkDeleteConformation
    public function bulkDeleteConformation(){
        $this->bulkDeleteConform = true;
    }

    // bulkDeleteCancel
    public function bulkDeleteCancel(){
        $this->bulkDeleteConform = false;
    }

    // bulkDelete
    public function bulkDelete(){
        //dd($this->selected);

       if($this->selected){

            foreach ($this->selected as $delId) {

        
                $data = NewsGallery::find($delId);

                // Delete Document
                $docFile = $data->image;
                if ( !empty($docFile) ){
                    // Delete by trait function
                    $this->docDelete($docFile, 'gallery/');
                    $this->docDelete($docFile, 'gallery/small/');
                    $this->docDelete($docFile, 'gallery/800-600/');
                }
                $data->delete();

            }
        }

        $this->selected = [];
        $this->selectAll = false;
        $this->bulkDeleteConform = false;
        //Tostar alert
        $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Deleted Successfully &#128512.', 'icon' => 'success'] );
       
    }

    //reset form
    public function resetForm(){
        $this->images = [];
    }

    //add data btn click
    public function addData(){
        //Reset Form values
        $this->resetForm();
        //Open Model
        $this->openModal();
    }
 
    // Save new Data
    public function save()
    {
        $this->validate([
            'images.*' => 'required|image|max:5000', // 1MB Max
        ]);
 
       
        // Multiple Image Save
        foreach ($this->images as $image) {

      
            $imageName = $image->hashName();
           
            //Store Original Image
            $image->storePublicly( 'gallery', 'custom');

            // Resized Image Save
            Image::make($image)
            ->resize(300, 200)
            ->save( 'images/gallery/small/'.$imageName );

            Image::make($image)
            ->resize(800, 600)
            ->save( 'images/gallery/800-600/'.$imageName );

            $data = new NewsGallery();
            $data->image      = $imageName;
            $data->status     = 1;
            $data->created_by = Auth::user()->id;
            $data->save();

        }

    
        //Close Modal
        $this->closeModal();

        //Tostar alert
        $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Saved Successfully &#128512.', 'icon' => 'success'] );

      
    }


    // Delete
    public function delete( $delId = null, $conf=0 ){

        // Delete comform valu make null
        $this->conformation = null;
       
        if($conf == 1){

            if( !empty($delId) ){
              
                $data = NewsGallery::find($delId);

                // Delete Document
                $docFile = $data->image;
                if ( !empty($docFile) ){
                    // Delete by trait function
                    $this->docDelete($docFile, 'gallery/');
                    $this->docDelete($docFile, 'gallery/small/');
                    $this->docDelete($docFile, 'gallery/800-600/');
                }

                
                // dd($val);
                $success = $data->delete();
        
               if($success){
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Deleted Successfully &#128512.', 'icon' => 'success'] );
                }else{
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
                }
            }

           
        }
       
      
    }

    // Status change
    public function changeStatus( $stId = null, $conf=0 ){

        // Status comform valu make null
        $this->statusConform = null;

        // Check Conformation ok
        if($conf == 1){

            // Id get or not
            if( !empty($stId) ){

                $data = NewsGallery::find($stId);

                if($data->status == 1){
                    $data->status = 0;
                }else{
                    $data->status = 1;
                }

                $success = $data->save();

                if($success){
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Saved Successfully &#128512.', 'icon' => 'success'] );
                }else{
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
                }


            }else{
                //Tostar alert
                $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
            }

        }

    }




    public function render()
    {
        $allData = NewsGallery::query()
        //->search( trim(preg_replace('/\s+/' ,' ', $this->search)) )
        //->with('zoneData', 'managerData', 'officerData')
        ->orderBy($this->sortBy, $this->sortDirection)
        ->paginate($this->perPage); 

        return view('livewire.admin.news.gallery', compact('allData'));
    }
}
