<?php

namespace App\Http\Livewire\Admin\About;

use Livewire\Component;

use Livewire\WithPagination;
use Auth;
use App\Models\Admin\About\AboutHistory;

use App\Http\Livewire\Common\fileUpload\ImgUpFunctions;
use App\Http\Livewire\Common\dataTbl\Conformation;
use App\Http\Livewire\Common\dataTbl\TblComponants;
use App\Http\Livewire\Common\Modal\ModalOpenClose;


class History extends Component
{
    use WithPagination, ImgUpFunctions, Conformation, TblComponants, ModalOpenClose;

    protected $paginationTheme = 'bootstrap';
  
    public $image, $oldImage, $assetUrl, $date, $title, $message, $details;

    public function mount(){
        $this->assetUrl = asset('images/history/small').'/';
    }
  
    //reset form
    public function resetForm(){
        $this->date           = '';
        $this->title          = '';
        $this->details        = '';
        $this->image          = '';
        $this->oldImage       = '';
    }

    // Image 
    public function updatedImage(){
        $this->validate([
            'image'     => 'nullable|image|max:1024', // 1MB Max
        ]);
    }

    
    //add data btn click
    public function addData(){
        //Reset Form values
        $this->resetForm();
        // Clear summernote value
        $this->dispatchBrowserEvent('editorTextClear');
        //Open Model
        $this->openModal();
    }


    // Save new Data
    public function save($val=null){

        if($this->editId){

            //Validate
            $this->validate([
                'title'     => 'required|string|max:1000|unique:about_histories,title,'.$this->editId,
                'date'      => 'required|string|max:100',
                'details'   => 'required|string|max:20000',
                'image'     => 'nullable|image|max:1024', // 1MB Max
            ]);

            $data = AboutHistory::find($this->editId);

            // Check Image selected 
            if ( !empty($this->image) ) {
            // Delete file
                $imgFile = $data->image;
                if ( !empty($imgFile) ){
                    // Delete by trait function
                    $this->imgDelete($imgFile, 'history/');
                }
            }

            

        }else{
            //Validate
            $this->validate([
                'title'     => 'required|string|max:1000|unique:about_histories',
                'date'      => 'required|string|max:100',
                'details'   => 'required|string|max:20000',
                'image'     => 'nullable|image|max:1024', // 1MB Max
            ]);

            $data = new AboutHistory();
        }

        // Image store
        if ( !empty($this->image) ) {
            // Image upload by trait function
            $imageName = $this->imgUpload($this->image, 'history/');
            //dd($imageName);
            $data->image = $imageName;
        }

        $data->title      = $this->title;
        $data->date       = $this->date;
        $data->details    = $this->details;
        $data->status     = 1;
        $data->created_by = Auth::user()->id;
        $success          = $data->save();

        //Close Modal
        $this->closeModal();

        //Reset Form
        $this->resetForm();
      
        if($success){
            //Tostar alert
            $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Saved Successfully &#128512.', 'icon' => 'success'] );
        }else{
            //Tostar alert
            $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
        }

        

    }

    // Single Data
    public function edit($val){

        $data = AboutHistory::find($val);

        // dd($val, $data);

        $this->title    = $data->title;
        $this->date     = $data->date;
        $this->oldImage = $data->image;

        // Edited text added in Summernote 
        $this->dispatchBrowserEvent('editorText', ['messege' => $data->details] );

        // set edit form Id
        $this->editId = $val;
        //Open Modal
        $this->openModal('Edit data', $val);
      
    }

    // Delete
    public function delete( $delId = null, $conf=0 ){

        // Delete comform valu make null
        $this->conformation = null;
       
        if($conf == 1){

            if( !empty($delId) ){
              
                $data = AboutHistory::find($delId);

                // Delete file
                $imgFile = $data->image;
                if ( !empty($imgFile) ){
                    // Delete by trait function
                    $this->imgDelete($imgFile, 'history/');
                }

                // dd($val);
                $success = $data->delete();
        
               if($success){
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Deleted Successfully &#128512.', 'icon' => 'success'] );
                }else{
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
                }
            }

           
        }
       
      
    }

    // Status change
    public function changeStatus( $stId = null, $conf=0 ){

        // Status comform valu make null
        $this->statusConform = null;

        // Check Conformation ok
        if($conf == 1){

            // Id get or not
            if( !empty($stId) ){

                $data = AboutHistory::find($stId);

                if($data->status == 1){
                    $data->status = 0;
                }else{
                    $data->status = 1;
                }

                $success = $data->save();

                if($success){
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Saved Successfully &#128512.', 'icon' => 'success'] );
                }else{
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
                }


            }else{
                //Tostar alert
                $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
            }

        }

    }

    public function render()
    {
        $allData = AboutHistory::query()
        ->search( trim(preg_replace('/\s+/' ,' ', $this->search)) )
        //->with('zoneData', 'managerData', 'officerData')
        ->orderBy($this->sortBy, $this->sortDirection)
        ->paginate($this->perPage);

        return view('livewire.admin.about.history', compact('allData'));
    }
}
