<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;


use App\Models\User;
use App\Models\Admin\About\AboutHeadquarter;
use App\Models\Admin\About\AboutHistory;
use App\Models\Admin\About\AboutMission;
use App\Models\Admin\About\AboutVision;
use App\Models\Admin\Business\BusinessAll;
use App\Models\Admin\News\NewsEvent;
use App\Models\Admin\News\NewsGallery;
use App\Models\Admin\News\NewsPress;

class Index extends Component
{
    public $admin, $headquarter, $history, $mission, $vision, $businessAll, $event, $gallery, $press;

    public function mount(){
        $this->admin             = User::count();
        $this->headquarter       = AboutHeadquarter::where('status', '1')->count();
        $this->history           = AboutHistory::where('status', '1')->count();
        $this->mission           = AboutMission::where('status', '1')->count();
        $this->vision            = AboutVision::where('status', '1')->count();
        $this->businessAll       = BusinessAll::where('status', '1')->count();
        $this->event             = NewsEvent::where('status', '1')->count();
        $this->gallery           = NewsGallery::where('status', '1')->count();
        $this->press             = NewsPress::where('status', '1')->count();
    }

    public function render()
    {
        return view('livewire.admin.index');
    }
}
