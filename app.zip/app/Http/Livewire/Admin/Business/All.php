<?php

namespace App\Http\Livewire\Admin\Business;

use Livewire\Component;

use Livewire\WithPagination;
use Auth;
use App\Models\Admin\Business\BusinessAll;
use Image;

use App\Http\Livewire\Common\fileUpload\ImgUpFunctions;
use App\Http\Livewire\Common\dataTbl\Conformation;
use App\Http\Livewire\Common\dataTbl\TblComponants;
use App\Http\Livewire\Common\Modal\ModalOpenClose;


class All extends Component
{
    use WithPagination, ImgUpFunctions, Conformation, TblComponants, ModalOpenClose;

    protected $paginationTheme = 'bootstrap';
  
    public $image, $oldImage, $assetUrl, $docUrl, $name, $title, $website, $message, $details, $image2, $oldImage2, $image3, $oldImage3, $image4, $oldImage4, $image5, $oldImage5;

    public function mount(){
        $this->assetUrl = asset('images/business/small').'/';
    }
  
    //reset form
    public function resetForm(){
        $this->name           = '';
        $this->website          = '';
        $this->title          = '';
        $this->details        = '';
        $this->image          = '';
        $this->oldImage       = '';
        $this->image2         = '';
        $this->oldImage2      = '';
        $this->image3         = '';
        $this->oldImage3      = '';
        $this->image4         = '';
        $this->oldImage4      = '';
        $this->image5         = '';
        $this->oldImage5      = '';
    }

    // Image 
    public function updatedImage(){
        $this->validate([
            'image'     => 'nullable|image|max:1024', // 1MB Max
        ]);
    }

    public function updatedImage2(){
        $this->validate([
            'image2'     => 'nullable|image|max:1024', // 1MB Max
        ]);
    }

    public function updatedImage3(){
        $this->validate([
            'image3'     => 'nullable|image|max:1024', // 1MB Max
        ]);
    }

    public function updatedImage4(){
        $this->validate([
            'image4'     => 'nullable|image|max:1024', // 1MB Max
        ]);
    }

    public function updatedImage5(){
        $this->validate([
            'image5'     => 'nullable|image|max:1024', // 1MB Max
        ]);
    }

    
    //add data btn click
    public function addData(){
        //Reset Form values
        $this->resetForm(); 
        // Clear summernote value
        $this->dispatchBrowserEvent('editorTextClear');
        //Open Model
        $this->openModal();
    }


    // Save new Data
    public function save($val=null){

        if($this->editId){

            //Validate
            $this->validate([
                'name'       => 'required|string|max:1000|unique:business_alls,name,'.$this->editId,
                'website'    => 'nullable|string|max:1000',
                'title'      => 'required|string|max:1000',
                'details'    => 'required|string|max:40000',
                'image'      => 'nullable|image|max:1024', // 1MB Max
                'image2'     => 'nullable|image|max:1024', // 1MB Max
                'image3'     => 'nullable|image|max:1024', // 1MB Max
                'image4'     => 'nullable|image|max:1024', // 1MB Max
                'image5'     => 'nullable|image|max:1024', // 1MB Max
            ]);

            $data = BusinessAll::find($this->editId);

            // Check Image selected 
            if ( !empty($this->image) ) {
                // Delete file
                $imgFile = $data->image;
                if ( !empty($imgFile) ){
                    // Delete by trait function
                    $this->imgDelete($imgFile, 'business/');
                }
            }

            if ( !empty($this->image2) ) {
                    // Delete file
                    $imgFile2 = $data->image2;
                    if ( !empty($imgFile2) ){
                        // Delete by trait function
                        $this->imgDelete($imgFile2, 'business/');
                    }
                }

            if ( !empty($this->image3) ) {
                    // Delete file
                    $imgFile3 = $data->image3;
                    if ( !empty($imgFile3) ){
                        // Delete by trait function
                        $this->imgDelete($imgFile3, 'business/');
                    }
                }

            if ( !empty($this->image4) ) {
                    // Delete file
                    $imgFile4 = $data->image4;
                    if ( !empty($imgFile4) ){
                        // Delete by trait function
                        $this->imgDelete($imgFile4, 'business/');
                    }
                }

            if ( !empty($this->image5) ) {
                // Delete file
                    $imgFile5 = $data->image5;
                    if ( !empty($imgFile5) ){
                        // Delete by trait function
                        $this->imgDelete($imgFile5, 'business/');
                    }
                }

         

        }else{
            //Validate
            $this->validate([
                'name'       => 'required|string|max:1000|unique:business_alls',
                'website'    => 'nullable|string|max:1000',
                'title'      => 'required|string|max:1000',
                'details'    => 'required|string|max:40000',
                'image'      => 'nullable|image|max:1024', // 1MB Max
                'image2'     => 'nullable|image|max:1024', // 1MB Max
                'image3'     => 'nullable|image|max:1024', // 1MB Max
                'image4'     => 'nullable|image|max:1024', // 1MB Max
                'image5'     => 'nullable|image|max:1024', // 1MB Max
            ]);

            $data = new BusinessAll();
        }

        // Image store
        if ( !empty($this->image) ) {
            // $imageName = $this->imgUpload($this->image, 'business/');
            // $data->image = $imageName;

            $imageName =$this->image->hashName();
            $data->image = $imageName;
            //Store Original Image
            $this->image->storePublicly( 'business/', 'custom');
            // Resized Image Save
            $img = Image::make($this->image)
            ->resize(300, 200)
            ->save('images/business/small/'.$imageName);

            $img = Image::make($this->image)
            ->resize(1110, 450)
            ->save('images/business/1110-450/'.$imageName);
        }

        if ( !empty($this->image2) ) {
          
            $image2Name =$this->image2->hashName();
            $data->image2 = $image2Name;
            //Store Original Image
            $this->image2->storePublicly( 'business/', 'custom');
            // Resized Image Save
            $img = Image::make($this->image2)
            ->resize(300, 200)
            ->save('images/business/small/'.$image2Name);

            $img = Image::make($this->image2)
            ->resize(1110, 450)
            ->save('images/business/1110-450/'.$image2Name);
        }

        if ( !empty($this->image3) ) {
            $image3Name =$this->image3->hashName();
            $data->image3 = $image3Name;
            //Store Original Image
            $this->image3->storePublicly( 'business/', 'custom');
            // Resized Image Save
            $img = Image::make($this->image3)
            ->resize(300, 200)
            ->save('images/business/small/'.$image3Name);

            $img = Image::make($this->image3)
            ->resize(1110, 450)
            ->save('images/business/1110-450/'.$image3Name);
        }

        if ( !empty($this->image4) ) {
            $image4Name =$this->image4->hashName();
            $data->image4 = $image4Name;
            //Store Original Image
            $this->image4->storePublicly( 'business/', 'custom');
            // Resized Image Save
            $img = Image::make($this->image4)
            ->resize(300, 200)
            ->save('images/business/small/'.$image4Name);

            $img = Image::make($this->image4)
            ->resize(1110, 450)
            ->save('images/business/1110-450/'.$image4Name);
        }

        if ( !empty($this->image5) ) {
            $image5Name =$this->image5->hashName();
            $data->image5 = $image5Name;
            //Store Original Image
            $this->image5->storePublicly( 'business/', 'custom');
            // Resized Image Save
            $img = Image::make($this->image5)
            ->resize(300, 200)
            ->save('images/business/small/'.$image5Name);

            $img = Image::make($this->image5)
            ->resize(1110, 450)
            ->save('images/business/1110-450/'.$image5Name);
        }

     

        $data->name       = $this->name;
        $data->title      = $this->title;
        $data->details    = $this->details;
        $data->website    = $this->website;
        $data->status     = 1;
        $data->created_by = Auth::user()->id;
        $success          = $data->save();

        //Close Modal
        $this->closeModal();

        //Reset Form
        $this->resetForm();
      
        if($success){
            //Tostar alert
            $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Saved Successfully &#128512.', 'icon' => 'success'] );
        }else{
            //Tostar alert
            $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
        }

        

    }

    // Single Data
    public function edit($val){

        $data = BusinessAll::find($val);

        // dd($val, $data);
        $this->name        = $data->name;
        $this->website     = $data->website;
        $this->title       = $data->title;
        $this->details     = $data->details;
        $this->oldImage    = $data->image;
        $this->oldImage2   = $data->image2;
        $this->oldImage3   = $data->image3;
        $this->oldImage4   = $data->image4;
        $this->oldImage5   = $data->image5;

        // Edited text added in Summernote 
        $this->dispatchBrowserEvent('editorText', ['messege' => $data->details] );

        // set edit form Id
        $this->editId = $val;
        //Open Modal
        $this->openModal('Edit data', $val);
      
    }

    // Delete
    public function delete( $delId = null, $conf=0 ){

        // Delete comform valu make null
        $this->conformation = null;
       
        if($conf == 1){

            if( !empty($delId) ){
              
                $data = BusinessAll::find($delId);

                // Check Image selected 
                if ( !empty($data->image) ) {
                    // Delete file
                    $imgFile = $data->image;
                    if ( !empty($imgFile) ){
                        // Delete by trait function
                        $this->imgDelete($imgFile, 'business/');
                    }
                }
    
                if ( !empty($data->image2) ) {
                    // Delete file
                        $imgFile2 = $data->image2;
                        if ( !empty($imgFile2) ){
                            // Delete by trait function
                            $this->imgDelete($imgFile2, 'business/');
                        }
                    }
    
                if ( !empty($data->image3) ) {
                        // Delete file
                        $imgFile3 = $data->image3;
                        if ( !empty($imgFile3) ){
                            // Delete by trait function
                            $this->imgDelete($imgFile3, 'business/');
                        }
                    }

                if ( !empty($data->image4) ) {
                        // Delete file
                        $imgFile4 = $data->image4;
                        if ( !empty($imgFile4) ){
                            // Delete by trait function
                            $this->imgDelete($imgFile4, 'business/');
                        }
                    }

                if ( !empty($data->image5) ) {
                        // Delete file
                        $imgFile5 = $data->image5;
                        if ( !empty($imgFile5) ){
                            // Delete by trait function
                            $this->imgDelete($imgFile5, 'business/');
                        }
                    }

                

                // dd($val);
                $success = $data->delete();
        
               if($success){
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Deleted Successfully &#128512.', 'icon' => 'success'] );
                }else{
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
                }
            }

           
        }
       
      
    }

    // Status change
    public function changeStatus( $stId = null, $conf=0 ){

        // Status comform valu make null
        $this->statusConform = null;

        // Check Conformation ok
        if($conf == 1){

            // Id get or not
            if( !empty($stId) ){

                $data = BusinessAll::find($stId);

                if($data->status == 1){
                    $data->status = 0;
                }else{
                    $data->status = 1;
                }

                $success = $data->save();

                if($success){
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Saved Successfully &#128512.', 'icon' => 'success'] );
                }else{
                    //Tostar alert
                    $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
                }


            }else{
                //Tostar alert
                $this->dispatchBrowserEvent('toastMsg', ['messege' => 'Somthing Going Wrong &#128549.', 'icon' => 'error'] );
            }

        }

    }


    public function render()
    {
        $allData = BusinessAll::query()
        ->search( trim(preg_replace('/\s+/' ,' ', $this->search)) )
        //->with('zoneData', 'managerData', 'officerData')
        ->orderBy($this->sortBy, $this->sortDirection)
        ->paginate($this->perPage);

        return view('livewire.admin.business.all', compact('allData'));
    }
}
